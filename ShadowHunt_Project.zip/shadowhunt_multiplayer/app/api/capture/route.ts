import { NextRequest } from 'next/server';
import { requireUser, jsonError } from '../_auth';
import { distanceMetres } from '../../../lib/game';
export async function POST(req:NextRequest){
 try{
  const {admin,user}=await requireUser(req); const b=await req.json();
  const {data:room}=await admin.from('rooms').select('status,started_at').eq('id',b.roomId).single();
  if(room?.status!=='active'||!room.started_at) throw new Error('Match is not active');
  if(Date.now()-new Date(room.started_at).getTime()<180000) throw new Error('Hunters cannot capture during the Shadow head start');
  const {data:hunter}=await admin.from('players').select('*').eq('room_id',b.roomId).eq('user_id',user.id).single();
  const {data:shadow}=await admin.from('players').select('*').eq('room_id',b.roomId).eq('user_id',b.targetUserId).single();
  if(!hunter||hunter.role!=='hunter'||hunter.status!=='active') throw new Error('Only active Hunters can capture');
  if(!shadow||shadow.role!=='shadow'||shadow.status!=='active'||hunter.lat==null||shadow.lat==null||hunter.lng==null||shadow.lng==null) throw new Error('Player location unavailable');
  if(Date.now()-new Date(hunter.updated_at).getTime()>30000||Date.now()-new Date(shadow.updated_at).getTime()>30000) throw new Error('GPS positions are stale; refresh both locations');
  const metres=distanceMetres({lat:hunter.lat,lng:hunter.lng},{lat:shadow.lat,lng:shadow.lng});
  if(metres>30) throw new Error(`Too far away (${Math.round(metres)} m). Get within 30 metres.`);
  const {error}=await admin.from('players').update({status:'captured'}).eq('id',shadow.id).eq('status','active');
  if(error) throw error;
  return Response.json({ok:true,distance:Math.round(metres)});
 }catch(e){return jsonError(e);}
}
