import { NextRequest } from 'next/server';
import { requireUser, jsonError } from '../../_auth';
export async function POST(req:NextRequest){
 try{
  const {admin,user}=await requireUser(req); const {roomId}=await req.json();
  const {error}=await admin.from('players').update({status:'left',lat:null,lng:null}).eq('room_id',roomId).eq('user_id',user.id);
  if(error) throw error;
  return Response.json({ok:true});
 }catch(e){return jsonError(e);}
}
