import { NextRequest } from 'next/server';
import { requireUser, jsonError } from '../../_auth';
export async function POST(req:NextRequest){
 try{
  const {admin,user}=await requireUser(req); const {roomId}=await req.json();
  const {data:room}=await admin.from('rooms').select('*').eq('id',roomId).single();
  if(!room||room.host_id!==user.id) throw new Error('Only the room host can start the match');
  if(room.status!=='lobby') throw new Error('Match is not in the lobby');
  const {count}=await admin.from('players').select('*',{count:'exact',head:true}).eq('room_id',roomId).eq('status','active');
  if((count||0)<2) throw new Error('At least two players are required');
  const {error}=await admin.from('rooms').update({status:'active',started_at:new Date().toISOString()}).eq('id',roomId).eq('status','lobby');
  if(error) throw error;
  return Response.json({ok:true});
 }catch(e){return jsonError(e);}
}
