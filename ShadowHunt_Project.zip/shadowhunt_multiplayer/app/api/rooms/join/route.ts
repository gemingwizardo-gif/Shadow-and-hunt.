import { NextRequest } from 'next/server';
import { requireUser, jsonError } from '../../_auth';
export async function POST(req:NextRequest){
 try{
  const {admin,user}=await requireUser(req); const b=await req.json(); const code=String(b.code||'').toUpperCase();
  if(!/^[A-Z0-9]{6}$/.test(code)) throw new Error('Enter a valid six-character room code');
  const {data:room,error}=await admin.from('rooms').select('*').eq('code',code).eq('status','lobby').maybeSingle();
  if(error||!room) throw new Error('Room not found or match already started');
  const {count}=await admin.from('players').select('*',{count:'exact',head:true}).eq('room_id',room.id).eq('status','active');
  if((count||0)>=30) throw new Error('Room is full (30 player limit)');
  const {error:pe}=await admin.from('players').upsert({room_id:room.id,user_id:user.id,role:b.role==='hunter'?'hunter':'shadow',display_name:String(b.displayName||'Player').slice(0,24),status:'active'},{onConflict:'room_id,user_id'});
  if(pe) throw pe;
  return Response.json({room});
 }catch(e){return jsonError(e);}
}
