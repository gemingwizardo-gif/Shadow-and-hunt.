import { NextRequest } from 'next/server';
import { requireUser, jsonError } from '../../_auth';
function code(){return Math.random().toString(36).slice(2,8).toUpperCase();}
export async function POST(req:NextRequest){
 try{
  const {admin,user}=await requireUser(req); const body=await req.json();
  const displayName=String(body.displayName||'Player').slice(0,24);
  const role=body.role==='hunter'?'hunter':'shadow';
  let room:any, error:any;
  for(let i=0;i<5;i++){const result=await admin.from('rooms').insert({code:code(),host_id:user.id,status:'lobby'}).select().single();room=result.data;error=result.error;if(!error)break;}
  if(error) throw error;
  const {error:pe}=await admin.from('players').insert({room_id:room.id,user_id:user.id,role,display_name:displayName,status:'active'});
  if(pe) throw pe;
  return Response.json({room});
 }catch(e){return jsonError(e);}
}
