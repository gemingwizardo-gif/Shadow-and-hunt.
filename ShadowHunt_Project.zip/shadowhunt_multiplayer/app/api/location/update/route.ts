import { NextRequest } from 'next/server';
import { requireUser, jsonError } from '../../_auth';
export async function POST(req:NextRequest){
 try{
  const {admin,user}=await requireUser(req); const b=await req.json();
  const lat=Number(b.lat),lng=Number(b.lng),accuracy=Number(b.accuracy||9999);
  if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180) throw new Error('Invalid GPS coordinates');
  if(accuracy>150) throw new Error('GPS accuracy is too low; move outdoors and retry');
  const {data:player}=await admin.from('players').select('id,room_id').eq('room_id',b.roomId).eq('user_id',user.id).eq('status','active').single();
  if(!player) throw new Error('You are not an active player in this room');
  const {data:room}=await admin.from('rooms').select('status').eq('id',b.roomId).single();
  if(room?.status!=='active') throw new Error('Location sharing is only available during an active match');
  const {error}=await admin.from('players').update({lat,lng,accuracy,updated_at:new Date().toISOString()}).eq('id',player.id);
  if(error) throw error;
  return Response.json({ok:true});
 }catch(e){return jsonError(e);}
}
